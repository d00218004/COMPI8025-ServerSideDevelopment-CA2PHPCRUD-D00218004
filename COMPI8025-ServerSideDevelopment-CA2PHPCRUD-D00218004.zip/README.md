# PHP CRUD
A simple PHP CRUD application with a MySQL Database
### Instructions
* Create a MySQL database called php-crud in PHP MyAdmin
* Run the code in the sql-db.txt file in PHP MyAdmin
* Move the PHP files in to your htdocs folder so Apache can process the PHP code
* Configure the database.php file to connect to your SQL database

