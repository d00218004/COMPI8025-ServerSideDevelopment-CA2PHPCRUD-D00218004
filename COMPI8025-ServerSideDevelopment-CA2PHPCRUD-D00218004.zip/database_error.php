<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>SAMSUNG ELECTRONICS</title>
    <link rel="stylesheet" type="text/css" href="./scss/main.css">
</head>
<!-- the body section -->
<body>
<header><img src="./image-resized/black-samsung-logo.png" /></header>

    <main>
        <h1>Database Error</h1>
        <p>Error message: <?php echo $error_message; ?></p>
        <p>&nbsp;</p>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?>SAMSUNG ELECTRONICS & CO, Ltd.</p>     
    </footer>
</body>
</html>